"""
Simula o Arduino enviando leituras para o Flask (sem precisar da placa).
Uso:  python simular_arduino.py            (envia 5 leituras)
      python simular_arduino.py 20         (envia 20 leituras)
Nao precisa instalar nada alem do Python.
"""
import json
import random
import sys
import time
import urllib.request

URL = "http://127.0.0.1:5000/api/telemetria"
qtd = int(sys.argv[1]) if len(sys.argv) > 1 else 5

for i in range(1, qtd + 1):
    dado = {
        "device_id": "teste",
        "placa": "simulador",
        "seq": i,
        "temp": round(random.uniform(1, 10), 1),
        "umid": round(random.uniform(50, 80), 1),
        "porta": random.choice(["aberta", "fechada"]),
        "luz_pct": random.randint(0, 100),
        "estado": "NORMAL",
    }
    req = urllib.request.Request(
        URL,
        data=json.dumps(dado).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5) as r:
        print(i, r.status, dado["temp"], dado["umid"])
    time.sleep(1)
