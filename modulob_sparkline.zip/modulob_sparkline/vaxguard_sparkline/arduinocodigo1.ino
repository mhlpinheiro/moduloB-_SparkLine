// VaxGuard Connect - versão básica (sem Wi-Fi / sem IA)
#include <DHT.h>


// ---- Pinos ----
#define ledR      9
#define ledY      8
#define ledG      7
#define botao1    4      // SOMENTE reconhece o alarme (só funciona em CRITICO)
#define tilt      3      // tilt switch da porta
#define buzzer    5
#define pinoDHT   2
#define tipoDHT   DHT11
#define pinoLDR   A0
#define rele      6

// ---- Faixa de temperatura (real de vacina seria 2 a 8) ----
#define TEMP_MIN        10.0
#define TEMP_MAX        28.0
#define MARGEM_ATENCAO  1.0

// ---- Tempos (ms) ----
#define INTERVALO_LEITURA   5000UL
#define PORTA_ATENCAO_MS    20000UL
#define PORTA_CRITICO_MS    60000UL
#define FORA_CRITICO_MS     30000UL
#define BIPE_ATENCAO_MS     10000UL
#define PISCA_MS            400UL
#define DEBOUNCE_MS         50UL

// ---- Outros ----
#define LIMITE_LUZ_PERCENT  70
// Nível lido quando a porta está ABERTA.
// Se ficar invertido (aberta aparece como fechada), troque LOW por HIGH.
#define PORTA_ABERTA_NIVEL  LOW
#define RELE_ON   LOW
#define RELE_OFF  HIGH

enum Estado { NORMAL, ATENCAO, CRITICO, RECONHECIDO, FALHA_SENSOR };
const char* nomeEstado[] = { "NORMAL", "ATENCAO", "CRITICO", "RECONHECIDO", "FALHA_SENSOR" };

DHT dht(pinoDHT, tipoDHT);

Estado estado = NORMAL;
float tempAtual = NAN;
float umidAtual = NAN;
int   luzPercent = 0;
bool  tempValida = false;
int   falhasDHT = 0;

bool portaAberta = false;
unsigned long portaDesde = 0;
unsigned long foraDesde = 0;
bool foraDaFaixa = false;

unsigned long ultimaLeitura = 0;
unsigned long ultimoBipe = 0;
unsigned long ultimoPisca = 0;
bool piscaLigado = false;
bool primeiraLeitura = true;

// botão (reconhecimento)
bool botaoAnterior = HIGH;
bool pedidoReconhecer = false;
unsigned long ultimoDebounce = 0;

// porta (debounce)
bool portaBruta = false;          // última leitura crua (true = aberta)
unsigned long portaUltimaMudanca = 0;

// ---------- Saídas ----------
void ventilador(bool on)
{
  digitalWrite(rele, on ? RELE_ON : RELE_OFF);
}

void leds(bool r, bool y, bool g)
{
  digitalWrite(ledR, r);
  digitalWrite(ledY, y);
  digitalWrite(ledG, g);
}

void aplicarEntrada(Estado e)
{
  switch (e)
  {
    case NORMAL:
      leds(LOW, LOW, HIGH);
      noTone(buzzer);
      ventilador(false);
      break;
    case ATENCAO:
      leds(LOW, HIGH, LOW);
      noTone(buzzer);
      ventilador(false);
      ultimoBipe = millis();
      break;
    case CRITICO:
      leds(HIGH, LOW, LOW);
      tone(buzzer, 1000);       // contínuo
      ventilador(true);
      break;
    case RECONHECIDO:
      noTone(buzzer);           // buzzer silencia
      ventilador(true);         // ventilação continua até normalizar
      ultimoPisca = millis();
      piscaLigado = true;
      leds(HIGH, LOW, LOW);
      break;
    case FALHA_SENSOR:
      noTone(buzzer);
      ventilador(false);
      ultimoPisca = millis();
      piscaLigado = true;
      leds(LOW, HIGH, LOW);
      break;
  }
}

void mudarEstado(Estado novo, const char* motivo)
{
  if (novo == estado) return;
  Serial.print("EVENTO: ");
  Serial.print(nomeEstado[estado]);
  Serial.print(" -> ");
  Serial.print(nomeEstado[novo]);
  Serial.print(" | motivo: ");
  Serial.println(motivo);
  estado = novo;
  aplicarEntrada(novo);
}

// ---------- Botão: só reconhece, e SÓ com CRITICO ativo ----------
void lerBotao()
{
  bool leitura = digitalRead(botao1);
  if (leitura != botaoAnterior && millis() - ultimoDebounce > DEBOUNCE_MS)
  {
    ultimoDebounce = millis();
    botaoAnterior = leitura;
    // borda de descida; só vale se o estado atual for CRITICO
    if (leitura == LOW && estado == CRITICO) pedidoReconhecer = true;
  }
}

// ---------- Porta (com debounce) ----------
void lerPorta()
{
  bool leitura = (digitalRead(tilt) == PORTA_ABERTA_NIVEL);

  if (leitura != portaBruta)
  {
    portaBruta = leitura;
    portaUltimaMudanca = millis();
  }

  // só aceita a mudança se ficou estável por DEBOUNCE_MS
  if (portaBruta != portaAberta && millis() - portaUltimaMudanca > DEBOUNCE_MS)
  {
    portaAberta = portaBruta;
    if (portaAberta) portaDesde = millis();
    Serial.print("PORTA: ");
    Serial.println(portaAberta ? "ABERTA" : "FECHADA");
  }
}

// ---------- Leitura periódica dos sensores ----------
void lerSensores()
{
  if (!primeiraLeitura && millis() - ultimaLeitura < INTERVALO_LEITURA) return;
  primeiraLeitura = false;
  ultimaLeitura = millis();

  float u = dht.readHumidity();
  float t = dht.readTemperature();

  int luz = analogRead(pinoLDR);
  luzPercent = map(luz, 0, 1023, 0, 100);

  if (isnan(u) || isnan(t))
  {
    falhasDHT++;
    Serial.print("Erro ao ler o DHT11! (");
    Serial.print(falhasDHT);
    Serial.println("/3)");
    return;
  }

  falhasDHT = 0;
  tempAtual = t;
  umidAtual = u;
  tempValida = true;

  bool fora = (t < TEMP_MIN || t > TEMP_MAX);
  if (fora && !foraDaFaixa) foraDesde = millis();
  foraDaFaixa = fora;

  Serial.print("Temp: ");
  Serial.print(t);
  Serial.print(" C | Umid: ");
  Serial.print(u);
  Serial.print(" % | Luz: ");
  Serial.print(luzPercent);
  Serial.print(" % | Porta: ");
  Serial.print(portaAberta ? "ABERTA" : "fechada");
  Serial.print(" | Estado: ");
  Serial.println(nomeEstado[estado]);
}

// ---------- Máquina de estados ----------
void avaliarEstado()
{
  // FALHA_SENSOR: 3 leituras inválidas seguidas
  if (falhasDHT >= 3)
  {
    pedidoReconhecer = false;
    mudarEstado(FALHA_SENSOR, "3 leituras invalidas do DHT11");
    return;
  }

  if (!tempValida) return;   // ainda sem leitura válida

  unsigned long portaTempo = portaAberta ? (millis() - portaDesde) : 0;
  unsigned long foraTempo  = foraDaFaixa ? (millis() - foraDesde) : 0;

  bool criticoTemp  = foraDaFaixa && foraTempo > FORA_CRITICO_MS;
  bool criticoPorta = portaTempo > PORTA_CRITICO_MS;
  bool critico = criticoTemp || criticoPorta;

  bool pertoLimite = (tempAtual <= TEMP_MIN + MARGEM_ATENCAO) ||
                     (tempAtual >= TEMP_MAX - MARGEM_ATENCAO);
  bool luzForte = (!portaAberta && luzPercent >= LIMITE_LUZ_PERCENT);
  bool atencao = pertoLimite || foraDaFaixa || (portaTempo > PORTA_ATENCAO_MS) || luzForte;

  if (critico)
  {
    const char* motivo = criticoTemp ? "temperatura fora da faixa > 30 s"
                                     : "porta aberta > 60 s";
    if (estado == RECONHECIDO)
    {
      // mantém reconhecido (buzzer mudo) enquanto o crítico durar
    }
    else if (estado == CRITICO && pedidoReconhecer)
    {
      mudarEstado(RECONHECIDO, "botao pressionado com CRITICO ativo");
    }
    else
    {
      mudarEstado(CRITICO, motivo);
    }
  }
  else if (atencao)
  {
    const char* motivo = portaTempo > PORTA_ATENCAO_MS ? "porta aberta > 20 s"
                       : foraDaFaixa ? "temperatura fora da faixa"
                       : pertoLimite ? "temperatura a menos de 1 C do limite"
                                     : "luz forte com porta fechada";
    mudarEstado(ATENCAO, motivo);
  }
  else
  {
    mudarEstado(NORMAL, "condicoes normalizadas");
  }

  pedidoReconhecer = false;   // consome o pedido
}

// ---------- Efeitos temporizados (piscar / bipe) ----------
void atualizarEfeitos()
{
  if (estado == ATENCAO)
  {
    if (millis() - ultimoBipe >= BIPE_ATENCAO_MS)
    {
      ultimoBipe = millis();
      tone(buzzer, 2000, 100);   // bipe curto, não bloqueante
    }
  }
  else if (estado == RECONHECIDO)
  {
    if (millis() - ultimoPisca >= PISCA_MS)
    {
      ultimoPisca = millis();
      piscaLigado = !piscaLigado;
      leds(piscaLigado, LOW, LOW);
    }
  }
  else if (estado == FALHA_SENSOR)
  {
    if (millis() - ultimoPisca >= PISCA_MS)
    {
      ultimoPisca = millis();
      piscaLigado = !piscaLigado;
      leds(!piscaLigado, piscaLigado, LOW);   // amarelo e vermelho alternando
    }
  }
}

void setup()
{
  Serial.begin(9600);
  dht.begin();

  digitalWrite(rele, RELE_OFF);
  pinMode(rele, OUTPUT);

  pinMode(ledR, OUTPUT);
  pinMode(ledY, OUTPUT);
  pinMode(ledG, OUTPUT);
  pinMode(buzzer, OUTPUT);
  pinMode(botao1, INPUT_PULLUP);
  pinMode(tilt, INPUT_PULLUP);

  // estado inicial da porta (evita falso evento no boot)
  portaBruta = (digitalRead(tilt) == PORTA_ABERTA_NIVEL);
  portaAberta = portaBruta;
  if (portaAberta) portaDesde = millis();

  aplicarEntrada(NORMAL);
}

void loop()
{
  lerBotao();
  lerPorta();
  lerSensores();
  avaliarEstado();
  atualizarEfeitos();
}
