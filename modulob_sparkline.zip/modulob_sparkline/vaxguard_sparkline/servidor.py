"""
VaxGuard Connect - servidor Flask local (SQLite) para armazenamento de vacinas

Rotas:
  GET  /                 -> tela web (dashboard)
  GET  /api/dados        -> ultima leitura + historico + eventos (usado pela tela)
  POST /api/telemetria   <- o Arduino envia as leituras aqui
  GET  /api/temperatura  -> ultima temperatura + historico
  GET  /api/umidade      -> ultima umidade + historico

Executar:
  pip install flask
  python servidor.py
"""
import sqlite3
from contextlib import closing
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory

DB = "vacinas.db"
app = Flask(__name__, static_folder="static")

# mesma faixa do sketch (TEMP_MIN / TEMP_MAX) - usada para sombrear o grafico
FAIXA_TEMP = {"min": 2.0, "max": 8.0}
OFFLINE_APOS_S = 20      # sem dados por mais que isso = placa offline


def conectar():
    con = sqlite3.connect(DB, timeout=10)
    con.row_factory = sqlite3.Row
    return con


def iniciar_banco():
    with closing(conectar()) as con, con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS leituras (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id   TEXT,
                seq         INTEGER,
                temp        REAL,
                umid        REAL,
                porta       TEXT,
                luz_pct     INTEGER,
                estado      TEXT,
                recebido_em TEXT
            )
        """)


# ---------- recebe os dados do Arduino ----------
@app.route("/api/telemetria", methods=["POST"])
def receber():
    d = request.get_json(silent=True)
    if not d:
        return jsonify(erro="JSON invalido"), 400

    with closing(conectar()) as con, con:
        con.execute(
            """INSERT INTO leituras
               (device_id, seq, temp, umid, porta, luz_pct, estado, recebido_em)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                d.get("device_id"), d.get("seq"),
                d.get("temp"), d.get("umid"),      # podem ser null (falha do DHT)
                d.get("porta"), d.get("luz_pct"), d.get("estado"),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
    return jsonify(ok=True), 201


# ---------- as duas rotas de consulta ----------
def consultar(coluna):
    # coluna vem sempre do proprio codigo ("temp" ou "umid"), nunca do usuario
    limite = request.args.get("limite", default=50, type=int)
    limite = max(1, min(limite, 1000))

    with closing(conectar()) as con:
        linhas = con.execute(
            f"""SELECT recebido_em, {coluna} AS valor, estado
                FROM leituras
                WHERE {coluna} IS NOT NULL
                ORDER BY id DESC LIMIT ?""",
            (limite,),
        ).fetchall()

    historico = [dict(l) for l in linhas]
    return jsonify(
        atual=historico[0] if historico else None,
        historico=historico,
    )


@app.route("/api/temperatura")
def temperatura():
    return consultar("temp")


@app.route("/api/umidade")
def umidade():
    return consultar("umid")


# ---------- tela web ----------
@app.route("/")
def painel():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/dados")
def dados():
    limite = request.args.get("limite", default=120, type=int)
    limite = max(1, min(limite, 1000))

    with closing(conectar()) as con:
        linhas = con.execute(
            "SELECT * FROM leituras ORDER BY id DESC LIMIT ?", (limite,)
        ).fetchall()
        total = con.execute("SELECT COUNT(*) FROM leituras").fetchone()[0]

    historico = [dict(l) for l in reversed(linhas)]   # do mais antigo p/ o mais novo
    ultima = historico[-1] if historico else None

    # eventos = mudancas de estado dentro do historico
    eventos, anterior = [], None
    for l in historico:
        if l["estado"] != anterior and anterior is not None:
            eventos.append({"em": l["recebido_em"], "de": anterior, "para": l["estado"]})
        anterior = l["estado"]

    segundos = None
    if ultima:
        segundos = int((datetime.now() - datetime.fromisoformat(ultima["recebido_em"])).total_seconds())

    return jsonify(
        ultima=ultima,
        historico=historico,
        eventos=eventos[-10:][::-1],
        total=total,
        segundos=segundos,
        online=segundos is not None and segundos <= OFFLINE_APOS_S,
        faixa=FAIXA_TEMP,
    )


if __name__ == "__main__":
    iniciar_banco()
    # 0.0.0.0 = aceita conexoes vindas da rede criada pela placa
    print("Painel: http://localhost:5000   (na rede da placa: http://192.168.4.2:5000)")
    app.run(host="0.0.0.0", port=5000)
